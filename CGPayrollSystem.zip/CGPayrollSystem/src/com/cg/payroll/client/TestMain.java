package com.cg.payroll.client;

import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayrollDBUtil;

public class TestMain {

	public static void main(String[] args) {
	PayrollDBUtil.getDBConnection();
	   PayrollServices services=new PayrollServicesImpl();
	System.out.println("connection is open");
//int associateId=services.acceptAssociateDetails("Harsh","Priya","harshpriya@gmail.com","cse","student ","365kjhgj ",4566,20000,5000,8000,3546877, "Icici","kkbk0031");           
//System.out.println("associateId"+associateId);
System.out.println(services.getAllAssociateDetails());

	}
}
